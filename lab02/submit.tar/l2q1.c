/* Purpose: Lab Exercise 2 Part 1
 * Author: Emmanuel Ojo
 * Date: September 16 2020
 *
 * Sources: None
 * 
 * All of the code in this program was written by myself (Emmanuel Ojo)
 *
 */

#include <stdio.h>

int main () {
  int number_one,number_two;
  number_one = 10, number_two = 5;

  printf("The total is %d\n",(number_one+10-number_two)/5);

  return 0;
}
